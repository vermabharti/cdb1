import 'dart:async';
import 'dart:convert';
import 'network_utils.dart';
import 'user.dart';

class RestDatasource {
  NetworkUtil _netUtil = new NetworkUtil(); 
  static final BASE_URL = "https://cdashboard.dcservices.in";
  static final LOGIN_URL = BASE_URL + "/HISUtilities/services/restful/DataService/DATAJSON/DashboardUserAuthentication";
  // static final _API_KEY = "somerandomkey";
  static final username = 'mobileUser';
  static final password = 'mob123';
  static final _API_KEY = 'Basic ' + base64Encode(utf8.encode('$username:$password'));

  Future<User> login(String username, String password) {
    return _netUtil.post(LOGIN_URL, body: {
      "Authorization": _API_KEY,
      "username": username,
      "password": password
    }).then((dynamic res) {
      print(res.toString());
      if(res["error"]) throw new Exception(res["error_msg"]);
      return new User.map(res["user"]);
    });
  }
}