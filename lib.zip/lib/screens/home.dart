import 'package:flutter/material.dart';
import 'menu.dart';
import 'dart:convert';
import 'dart:io';
import 'package:centraldashboard/url.dart'; 
import 'package:http/http.dart';
import 'package:http/io_client.dart'; 
import 'dart:ui'; 
// import 'package:centraldashboard/services/json.dart'; 

void main() {
  runApp(new HomeScreen());
}
 
class MyHomePage extends StatefulWidget { 
  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {    
// List<MenuList> list = List();
var isLoading = false; 
  
  Future<String> _fetchMainMenu() async {   
  setState(() {
      isLoading = true;
    });

    bool trustSelfSigned = true; 
    HttpClient httpClient = new HttpClient()
    ..badCertificateCallback = ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient); 

    String username = 'mobileUser';
    String password = 'mob123';
    String basicAuth = 'Basic ' + base64Encode(utf8.encode('$username:$password'));
    String url = BASE_URL + MENU_URL;  
    Map<String,String> headers = {'content-type':'text/plain','authorization':basicAuth};   

    final data = jsonEncode({"primaryKeys":["10001"]});    

    Response response = await ioClient.post(url, headers: headers, body: data);    
    if(response.statusCode == 200){
    var data_ =  json.decode(response.body); 
    var rest = data_["dataValue"] as List;
    print(rest);  
    } else {
      throw Exception('Failed to load photos');
    }
  }

  Widget getList() {
  List<String> list = getListItems();
  ListView myList = new ListView.builder(
    itemCount: list.length,
    itemBuilder: (context, index) {  
    return 
     new GestureDetector(
              onTap: (){
                // _fetchMainMenu();
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Menu()),
                );
              },
      child: new Container(              
        width: MediaQuery.of(context).size.width,
        margin: const EdgeInsets.fromLTRB(15, 20, 15, 5),
        padding: const EdgeInsets.all(20.0), 
        decoration: new BoxDecoration(borderRadius: new BorderRadius.all(new Radius.circular(10.0)),
        //  boxShadow: <BoxShadow>[
        //     BoxShadow(
        //       color: Color(0xff68e3c0).withOpacity(0.8),
        //       spreadRadius: 0,
        //       blurRadius: 10,
        //       offset: Offset(-1, -2), 
        //     ),
        //   ],
        gradient: new LinearGradient(colors: [Color(0xff68e3c0), Color(0xff6aead7) ],
        begin: Alignment.centerLeft, end: Alignment.centerRight, tileMode: TileMode.clamp)),           
        child: new Row (
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          new Padding(
            padding: const EdgeInsets.fromLTRB(0, 0, 10, 0),
            child: 
          new Icon(Icons.dashboard,
          color: Colors.white,
          size: 25),
          ),
          new Text(
            list[index],
            style: TextStyle(
              color:Colors.white,
              fontFamily: 'Open Sans',
              fontWeight:  FontWeight.w500,
              fontSize: 16
            )
          ),]
        ), 
      // child: new Text(list[index]),
    ),
     );
  });
  return myList;
}

List<String> getListItems(){
return ["Dashboard", "Admin Dashboard (Uat Dashboard)", "Admin New" , "Job Dashboard", "Stockout V 2.0"];
}

  @override
   void initState(){
    this. _fetchMainMenu();
  }

  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(
          'Central Dashboard',
          style:TextStyle(
            color:Color(0xffffffff),
            fontSize:20,
            fontWeight: FontWeight.w400,
            fontFamily: 'Open Sans',
          )),
        backgroundColor: Color(0xff283643),
      ), 
      body: Container(
        child:  getList() ,
      ),
    );     
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var title = 'Webview Demo';
    return new MaterialApp(
        debugShowCheckedModeBanner: false,
        title: title,        
        routes: {},
        home: new MyHomePage()
    );
  }
}