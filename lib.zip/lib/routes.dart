import 'package:flutter/material.dart'; 
import 'screens/home.dart';
import 'screens/login.dart';
import 'screens/menu.dart';

final routes = {  
  '/'       :       (BuildContext context) => new LoginScreen(),
  '/login'  :       (BuildContext context) => new LoginScreen(),
  '/home'   :       (BuildContext context) => new HomeScreen(),
  '/menu'   :       (BuildContext context) => new Menu(),
};