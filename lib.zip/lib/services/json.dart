class LoginData{

  final List<String> dataHeading;
  final List<Object> dataValue;
  final List<String> dataType;

  LoginData({this.dataHeading, this.dataValue, this.dataType});
   
  factory LoginData.fromJson(Map<String, dynamic> parsedJson){

    var head = parsedJson["dataHeading"];
    List<String> dataheading = head.cast<String>();
    
    var value = parsedJson["dataValue"]; 
    List<String> datavalue = value.cast<String>(); 

        var type = parsedJson["dataType"];
        List<String> datatype = type.cast<String>();
        
        return new LoginData(
          dataHeading: dataheading,
          dataValue: datavalue,
          dataType: datatype
        );
      }      
    } 
     