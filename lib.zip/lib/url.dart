// base url
const BASE_URL = 'https://cdashboard.dcservices.in';
//login web service
const LOGIN_URL = '/HISUtilities/services/restful/DataService/DATAJSON/DashboardUserAuthentication';
//menu web service
const MENU_URL = '/HISUtilities/services/restful/DataService/DATAJSON/MobileAppMenuService';
