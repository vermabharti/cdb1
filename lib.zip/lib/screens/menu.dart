import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

void main() => runApp(new Menu());

class MyMenu extends StatefulWidget {
  @override
  _MyMenuState createState() => new _MyMenuState();
}

class _MyMenuState extends State<MyMenu>{
   void _openmenu(){
    Navigator.popAndPushNamed(context, '/widget');}
  void _opennextmenu(){
    Navigator.popAndPushNamed(context, '/widget_1');}   
  @override
  Row toolbar = new Row(
  children: <Widget>[
    new Icon(Icons.arrow_back),
    new Icon(Icons.menu),
    new Expanded(child: new Text("widget.title")),
    new Icon(Icons.arrow_forward)
  ]
);
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        leading: IconButton(icon:Icon(Icons.arrow_back),
          onPressed:() => Navigator.pop(context, false),
        ),
        title: new Text(
          'EDL Details',
          style:TextStyle(
            color:Color(0xffffffff),
            fontSize:20,
            fontWeight: FontWeight.w400,
            fontFamily: 'Open Sans',
          )),
        backgroundColor: Color(0xff283643),
      ),
      drawer: new Drawer(
        child: new ListView(
          children: <Widget> [
            new Container(
              height: 80,
              alignment: Alignment.centerLeft,
            child: new DrawerHeader(
              child: new Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[                  
                  new Text(
                    'Sub Menu',
                    style:TextStyle(
                      color:Color(0xff000000),
                      fontSize:20,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Open Sans',
                    )), 
                    new IconButton(
                      icon: new Icon(Icons.close),
                      highlightColor: Colors.pink,
                      onPressed: (){Navigator.pop(context);},
                    ),
    
                ],
              )                            
              ),              
              ),
              
            new ListTile(
              title: new Text(
                'EDL Details',
                style:TextStyle(
                      color:Color(0xff000000),
                      fontFamily: 'Open Sans',
                    )),
              trailing: Icon(Icons.arrow_forward),
              onTap: () { 
                _openmenu();
              },
            ),
            new ListTile(
              title: new Text(
                'Rate Contract',
                style:TextStyle(
                      color:Color(0xff000000),
                      fontFamily: 'Open Sans',
                    )),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {_opennextmenu();},
            ),
            new ListTile(
              title: new Text(
                'Demand And Procurement',
                style:TextStyle(
                      color:Color(0xff000000),
                      fontFamily: 'Open Sans',
                    )),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {_opennextmenu();},
            ),
            new ListTile(
              title: new Text(
                'Common Essential',
                style:TextStyle(
                      color:Color(0xff000000),
                      fontFamily: 'Open Sans',
                    )),
              trailing: Icon(Icons.arrow_forward),
              onTap: () {_opennextmenu();},
            ),
            new Divider(),
            new ListTile(
              title:new Text(
                'Logout',
                style:TextStyle(
                      color:Color(0xff000000),
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Open Sans',
                    ))
            )
          ],
        )
      ),
      body: Container(
      //  child: WebviewScaffold(
      //     url: "https://flutter.dev/",
      //     withJavascript: true,  
      //     withZoom: true,  
      //   ) ,
      child: Text('hello world'),
      ),
       floatingActionButton: new FloatingActionButton(
          elevation: 0.0,
          child: new Icon(Icons.arrow_back),
          backgroundColor: new Color(0xff283643),
          onPressed: (){ Navigator.pop(context); }      
      ) 
    );
  }
}

class Menu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var title = 'Webview Demo';
    return new MaterialApp(
        debugShowCheckedModeBanner: false,
        title: title,        
        routes: {
          '/widget': (_) => new WebviewScaffold(
            url: "https://flutter.dev/",
            appBar: new AppBar(
              title: const Text('EDL Details',
              style:TextStyle(
                color:Color(0xffffffff),
                fontSize:20,
                fontWeight: FontWeight.w400,
                fontFamily: 'Open Sans',
              ),
            ),
            backgroundColor: Color(0xff283643),
            ),
            withZoom: false,
            withLocalStorage: true,
          ),
          '/widget_1': (_) => new WebviewScaffold(
            url: "https://www.w3schools.com/",
            appBar: new AppBar(
              title: const Text('Rate Contract',
              style:TextStyle(
                color:Color(0xffffffff),
                fontSize:20,
                fontWeight: FontWeight.w400,
                fontFamily: 'Open Sans',
              ),
              ), 
              elevation: 0.0,            
              backgroundColor: Color(0xff283643),
            ),
            withZoom: false,
            withLocalStorage: true,
          )
        },
        home: new MyMenu()
    );
  }
}

// import 'package:flutter/material.dart';

// void main() => runApp(MenuScreen());

// class MenuScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Welcome to Flutter',
//       home: Scaffold(
//         appBar: AppBar(
//           title: Text('Welcome to Flutter'),
//         ),
//         body: Center(
//           child: Text('Hello World'),
//         ),
//       ),
//     );
//   }
// }