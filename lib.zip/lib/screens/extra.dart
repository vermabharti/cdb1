import 'package:flutter/material.dart';
import 'menu.dart';
import 'dart:convert';
import 'dart:io';
import 'package:centraldashboard/url.dart'; 
import 'package:http/http.dart';
import 'package:http/io_client.dart'; 
import 'dart:ui'; 
import 'package:centraldashboard/services/json.dart';

Future<MenuList> _fetchMainMenu() async {  
    bool trustSelfSigned = true;
    // Certificate_verife
    HttpClient httpClient = new HttpClient()
    ..badCertificateCallback = ((X509Certificate cert, String host, int port) => trustSelfSigned);
    IOClient ioClient = new IOClient(httpClient); 
    String username = 'mobileUser';
    String password = 'mob123';
    String basicAuth = 'Basic ' + base64Encode(utf8.encode('$username:$password'));
    String url = BASE_URL + MENU_URL;  
    Map<String,String> headers = {'content-type':'text/plain','authorization':basicAuth};   
    final data = jsonEncode({"primaryKeys":["10001"]}); 
    Response response = await ioClient.post(url, headers: headers, body: data);
    // Map<String, dynamic> responseJson = json.decode(response.body);   
    // print(Utf8Codec().decode(response.bodyBytes)); 
    if(response.statusCode == 200){
     return MenuList.fromJson(json.decode(response.body));
    } else { 
        throw Exception('Failed to load post');
    }
  }

void main() {
  runApp(new HomeScreen());
}
 
class MyHomePage extends StatefulWidget { 
  @override
  _MyHomePageState createState() => new _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {    
Future<MenuList> list;
  @override
  void initState() {
    super.initState();
    list = _fetchMainMenu();
  }
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: new Text(
          'Central Dashboard',
          style:TextStyle(
            color:Color(0xffffffff),
            fontSize:20,
            fontWeight: FontWeight.w400,
            fontFamily: 'Open Sans',
          )),
        backgroundColor: Color(0xff283643),
      ),  
      body: Builder(
        builder: (context) =>    
      Container(        
        child: Column(          
          children: <Widget>[ 
            new Container(              
              width: MediaQuery.of(context).size.width,
              margin: const EdgeInsets.fromLTRB(15, 20, 15, 10),
              padding: const EdgeInsets.all(20.0), 
              decoration: new BoxDecoration(borderRadius: new BorderRadius.all(new Radius.circular(10.0)),
              // boxShadow: <BoxShadow>[
              //   BoxShadow(
              //     color: Color(0xff8186d5),
              //     blurRadius: 30.0, // has the effect of softening the shadow
              //     spreadRadius: 1.0, // has the effect of extending the shadow
              //     offset: Offset(
              //       1.0, // horizontal, move right 10
              //       1.0, // vertical, move down 10
              //     ),
              //     // offset: Offset(-9.0, -9.0),
              //     // blurRadius: 50.0,
              //   ),
              // ],
              gradient: new LinearGradient(colors: [Color(0xff68e3c0), Color(0xff6aead7) ],
              begin: Alignment.centerLeft, end: Alignment.centerRight, tileMode: TileMode.clamp)),           
              child: new Row (
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  new Icon(Icons.dashboard,
                  color: Colors.white,
                  size: 25),
                  new Text(
                    'DashBoard',
                    style: TextStyle(
                      color:Colors.white,
                      fontFamily: 'Open Sans',
                      fontSize: 15
                    )),]
                ),
              ),  
            new Container(
              width: MediaQuery.of(context).size.width,         
              margin: const EdgeInsets.fromLTRB(15, 10, 15, 10),
              padding: const EdgeInsets.all(20.0),
              decoration: new BoxDecoration(borderRadius: new BorderRadius.all(new Radius.circular(10.0)),            
              gradient: new LinearGradient(colors: [Color(0xffff6f5e), Color(0xfff2a6a6)],
              begin: Alignment.centerLeft, end: Alignment.centerRight, tileMode: TileMode.clamp)),
              child: new Row (
                 children: <Widget>[
                  new Icon(Icons.dashboard,
                  color: Colors.white,
                  size: 25),
                  new Text(
                    'report Set',
                    style: TextStyle(
                      color:Colors.white,
                      fontFamily: 'Open Sans',
                      fontSize: 15
                    )
                  ),
                ]
              ),
            ),          
            new GestureDetector(
              onTap: (){
                _fetchMainMenu();
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => MenuScreen()),
                // );
              },
             child: new Container(         
              width: MediaQuery.of(context).size.width,
              margin: const EdgeInsets.fromLTRB(15, 10, 15, 10),
              padding: const EdgeInsets.all(20.0),
              decoration: new BoxDecoration(borderRadius: new BorderRadius.all(new Radius.circular(10.0)),
              gradient: new LinearGradient(colors: [Color(0xff916dd5), Color(0xffd89cf6)],
                begin: Alignment.centerLeft, end: Alignment.centerRight, tileMode: TileMode.clamp)),               
              child: new Row (
                children: <Widget>[
                  new Icon(Icons.dashboard,
                  color: Colors.white,
                  size: 25),
                  new Text(
                    'Admin DashBoard',
                    style: TextStyle(
                      color:Colors.white,
                      fontFamily: 'Open Sans',
                      fontSize: 15
                    )
                  ),
                ]
              ),
            ), 
          ),             
        ],
      )        
    ),),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var title = 'Webview Demo';
    return new MaterialApp(
        debugShowCheckedModeBanner: false,
        title: title,        
        routes: {},
        home: new MyHomePage(),
    );
  }
}